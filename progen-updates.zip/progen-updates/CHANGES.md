# Pro-Gen updates: bug fixes + ArmorPaint-style texture painting

## Why "fusing" the ArmorPaint repo wasn't literal
`armorpaint` is a fork of the native ArmorPaint app — Haxe/C compiled via the
Kha framework (clang/Xcode/Android Studio required). Pro-Gen is an Electron +
Three.js JS app. The two can't share a codebase. Instead, this reimplements
ArmorPaint's core painting capability (layers, brushes, PBR channels) natively
in Pro-Gen's own Three.js stack, so Pro-Gen gains the feature without depending
on a native binary.

## Critical bugs fixed (found while integrating — both were blocking)
1. **`addObject()` never constructed a mesh** for any primitive except
   `ring` — `mesh` was referenced but never declared/assigned, so clicking
   Cube/Sphere/Cylinder/etc. threw a `ReferenceError` and added nothing.
2. **`three` was imported as a bare specifier** (`import * as THREE from
   'three'`) with nothing vendoring or mapping it — the renderer had no way
   to resolve it (no import map, no bundler, no local copy), so the app
   couldn't boot at all. Fixed by vendoring `three.module.js` +
   `OrbitControls.js` into `public/vendors/three/` and adding an
   `<script type="importmap">` in `index.html`.

## New feature: layered PBR texture painting (`public/paint/`)
- **`PaintEngine.js`** — per-mesh paint data: 4 channels (albedo, normal,
  roughness, metalness), each with its own layer stack. Layers are plain
  `<canvas>` elements composited via native canvas `globalCompositeOperation`
  blend modes (multiply, screen, overlay, soft-light, etc.) into a
  `THREE.CanvasTexture` wired straight into the mesh's `MeshStandardMaterial`.
- **`PaintController.js`** — the "Paint" toggle in the header, the panel in
  the right-hand properties column (channel tabs, brush size/hardness/
  opacity/color, eraser, layer list with visibility/opacity/blend-mode, add/
  remove layer, export-to-PNG), and pointer-driven brush strokes: raycasts
  the pointer against the selected mesh, converts the UV hit to canvas pixel
  space, and stamps a soft radial brush. Orbit controls are disabled only
  while an actual stroke is in progress, so navigating the model with the
  mouse still works normally.

## How to apply
Copy `public/` over your existing `progen/public/` (the `main.js`,
`index.html`, and `style.css` here have the integration diffs already
applied on top of your current versions — no separate patch step needed).
`node_modules` is untouched; nothing new needs installing.

## Not yet ported from ArmorPaint (future work, in rough priority order)
- Procedural/node-based materials (ArmorPaint's `nodes_material`) — this
  build only does raster painting, no node graphs.
- Baking (AO, curvature, etc. from `paint/sources/render`).
- Import of existing UV-unwrapped meshes with non-trivial UV layouts — the
  brush assumes reasonably distributed UVs, which Three.js's built-in
  primitive geometries provide by default.
