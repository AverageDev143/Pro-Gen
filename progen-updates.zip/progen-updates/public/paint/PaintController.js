import { PaintEngine, CHANNELS, CHANNEL_LABELS, BLEND_MODES } from './PaintEngine.js';

/**
 * PaintController — wires PaintEngine into the Pro-Gen viewport & UI.
 * Owns the "Paint" toggle, the channel/brush/layer panel, and pointer-driven
 * brush strokes raycast against the currently selected mesh.
 */
export class PaintController {
    constructor(app) {
        this.app = app; // the ProGen instance (scene, camera, renderer, raycaster, mouse, selectedObject)
        this.engine = new PaintEngine(512);
        this.active = false;
        this.painting = false;
        this.lastUV = null;
        this.brush = { size: 40, hardness: 0.6, opacity: 1, color: '#ffffff', erase: false };

        this._buildPanel();
        this._bindViewportEvents();
    }

    // ---- mode toggling -----------------------------------------------

    toggle(forceOn) {
        this.active = typeof forceOn === 'boolean' ? forceOn : !this.active;
        this.panelEl.classList.toggle('hidden', !this.active);
        document.getElementById('paintModeBanner')?.classList.toggle('hidden', !this.active);
        if (this.active) {
            this.app.controls.enabled = true; // orbit still allowed; painting uses left-drag only while over the mesh
            this._refreshForSelection();
        }
    }

    // ---- per-frame hook (call from app.animate()) ----------------------

    tick() {
        if (this.app.selectedObject) {
            this.engine.updateDirty(this.app.selectedObject);
        }
    }

    // ---- selection changes ---------------------------------------------

    onSelectionChanged() {
        if (this.active) this._refreshForSelection();
    }

    _refreshForSelection() {
        const mesh = this.app.selectedObject;
        if (!mesh) {
            this.panelEl.querySelector('.paint-no-object').classList.remove('hidden');
            this.panelEl.querySelector('.paint-body').classList.add('hidden');
            return;
        }
        this.panelEl.querySelector('.paint-no-object').classList.add('hidden');
        this.panelEl.querySelector('.paint-body').classList.remove('hidden');
        this.engine.ensureMeshPainted(mesh);
        this._renderLayerList();
    }

    // ---- viewport interaction -------------------------------------------

    _bindViewportEvents() {
        const dom = this.app.renderer.domElement;

        dom.addEventListener('pointerdown', (e) => {
            if (!this.active || e.button !== 0) return;
            const mesh = this.app.selectedObject;
            if (!mesh) return;
            const uv = this._raycastUV(e, mesh);
            if (!uv) return;
            this.painting = true;
            this.app.controls.enabled = false; // suppress orbit while stroking
            this.lastUV = uv;
            this.engine.stamp(mesh, uv, this._strokeOpts());
        });

        window.addEventListener('pointermove', (e) => {
            if (!this.active || !this.painting) return;
            const mesh = this.app.selectedObject;
            if (!mesh) return;
            const uv = this._raycastUV(e, mesh);
            if (!uv) return;
            if (this.lastUV) {
                this.engine.strokeBetween(mesh, this.lastUV, uv, this._strokeOpts());
            } else {
                this.engine.stamp(mesh, uv, this._strokeOpts());
            }
            this.lastUV = uv;
        });

        window.addEventListener('pointerup', () => {
            if (!this.painting) return;
            this.painting = false;
            this.lastUV = null;
            this.app.controls.enabled = true;
        });
    }

    _strokeOpts() {
        return {
            channelName: this.engine.activeChannelName,
            radius: this.brush.size,
            hardness: this.brush.hardness,
            opacity: this.brush.opacity,
            color: this.brush.color,
            erase: this.brush.erase
        };
    }

    _raycastUV(event, mesh) {
        const rect = this.app.renderer.domElement.getBoundingClientRect();
        const ndc = {
            x: ((event.clientX - rect.left) / rect.width) * 2 - 1,
            y: -((event.clientY - rect.top) / rect.height) * 2 + 1
        };
        this.app.raycaster.setFromCamera(ndc, this.app.camera);
        const hits = this.app.raycaster.intersectObject(mesh, false);
        if (hits.length === 0 || !hits[0].uv) return null;
        return { x: hits[0].uv.x, y: hits[0].uv.y };
    }

    // ---- panel construction ---------------------------------------------

    _buildPanel() {
        const panel = document.createElement('div');
        panel.id = 'paintPanel';
        panel.className = 'panel-section paint-panel hidden';
        panel.innerHTML = `
            <h3>Paint</h3>
            <div class="paint-no-object">
                <p class="no-selection-inline">Select an object to paint on it</p>
            </div>
            <div class="paint-body hidden">
                <div class="prop-group">
                    <label>Channel</label>
                    <div class="paint-channel-tabs">
                        ${CHANNELS.map(c => `<button type="button" class="paint-tab" data-channel="${c}">${CHANNEL_LABELS[c]}</button>`).join('')}
                    </div>
                </div>

                <div class="prop-group">
                    <label>Brush size <span id="brushSizeVal">${this.brush.size}</span>px</label>
                    <input type="range" id="brushSize" min="4" max="150" value="${this.brush.size}">
                </div>
                <div class="prop-group">
                    <label>Hardness <span id="brushHardnessVal">${Math.round(this.brush.hardness * 100)}</span>%</label>
                    <input type="range" id="brushHardness" min="0" max="100" value="${Math.round(this.brush.hardness * 100)}">
                </div>
                <div class="prop-group">
                    <label>Opacity <span id="brushOpacityVal">${Math.round(this.brush.opacity * 100)}</span>%</label>
                    <input type="range" id="brushOpacity" min="1" max="100" value="${Math.round(this.brush.opacity * 100)}">
                </div>
                <div class="prop-group">
                    <label>Color</label>
                    <input type="color" id="brushColor" class="prop-color" value="${this.brush.color}">
                </div>
                <div class="prop-group">
                    <label class="paint-erase-toggle">
                        <input type="checkbox" id="brushErase"> Eraser
                    </label>
                </div>

                <div class="prop-group">
                    <label>Layers <span id="activeChannelLabel"></span></label>
                    <div id="paintLayerList" class="paint-layer-list"></div>
                    <div class="paint-layer-actions">
                        <button type="button" id="addLayerBtn" class="tool-btn-small">+ Layer</button>
                        <button type="button" id="removeLayerBtn" class="tool-btn-small">Remove</button>
                    </div>
                </div>

                <div class="prop-group">
                    <button type="button" id="exportTexturesBtn" class="tool-btn-small paint-export-btn">Export Textures</button>
                </div>
            </div>
        `;

        const propertiesPanel = document.querySelector('.properties-panel');
        propertiesPanel.appendChild(panel);
        this.panelEl = panel;

        // channel tabs
        panel.querySelectorAll('.paint-tab').forEach(btn => {
            btn.addEventListener('click', () => {
                this.engine.setActiveChannel(btn.dataset.channel);
                this._updateChannelTabs();
                this._renderLayerList();
            });
        });
        this._updateChannelTabs();

        // brush controls
        panel.querySelector('#brushSize').addEventListener('input', (e) => {
            this.brush.size = parseInt(e.target.value, 10);
            panel.querySelector('#brushSizeVal').textContent = this.brush.size;
        });
        panel.querySelector('#brushHardness').addEventListener('input', (e) => {
            this.brush.hardness = parseInt(e.target.value, 10) / 100;
            panel.querySelector('#brushHardnessVal').textContent = e.target.value;
        });
        panel.querySelector('#brushOpacity').addEventListener('input', (e) => {
            this.brush.opacity = parseInt(e.target.value, 10) / 100;
            panel.querySelector('#brushOpacityVal').textContent = e.target.value;
        });
        panel.querySelector('#brushColor').addEventListener('input', (e) => {
            this.brush.color = e.target.value;
        });
        panel.querySelector('#brushErase').addEventListener('change', (e) => {
            this.brush.erase = e.target.checked;
        });

        // layers
        panel.querySelector('#addLayerBtn').addEventListener('click', () => {
            const mesh = this.app.selectedObject;
            if (!mesh) return;
            this.engine.addLayer(mesh, this.engine.activeChannelName);
            this._renderLayerList();
        });
        panel.querySelector('#removeLayerBtn').addEventListener('click', () => {
            const mesh = this.app.selectedObject;
            if (!mesh) return;
            const channel = this.engine.getChannel(mesh);
            const ok = this.engine.removeLayer(mesh, this.engine.activeChannelName, channel.activeLayerIndex);
            if (!ok) this.app.showToast?.('A channel needs at least one layer');
            this._renderLayerList();
        });

        panel.querySelector('#exportTexturesBtn').addEventListener('click', () => this._exportTextures());
    }

    _updateChannelTabs() {
        this.panelEl.querySelectorAll('.paint-tab').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.channel === this.engine.activeChannelName);
        });
        this.panelEl.querySelector('#activeChannelLabel').textContent =
            `(${CHANNEL_LABELS[this.engine.activeChannelName]})`;
    }

    _renderLayerList() {
        const mesh = this.app.selectedObject;
        const list = this.panelEl.querySelector('#paintLayerList');
        if (!mesh) { list.innerHTML = ''; return; }

        const channel = this.engine.getChannel(mesh);
        list.innerHTML = channel.layers.map((layer, i) => `
            <div class="paint-layer-row ${i === channel.activeLayerIndex ? 'active' : ''}" data-index="${i}">
                <input type="checkbox" class="paint-layer-visible" data-index="${i}" ${layer.visible ? 'checked' : ''}>
                <span class="paint-layer-name" data-index="${i}">${layer.name}</span>
                <select class="paint-layer-blend" data-index="${i}">
                    ${BLEND_MODES.map(m => `<option value="${m}" ${m === layer.blendMode ? 'selected' : ''}>${m}</option>`).join('')}
                </select>
                <input type="range" class="paint-layer-opacity" data-index="${i}" min="0" max="100" value="${Math.round(layer.opacity * 100)}">
            </div>
        `).join('');

        list.querySelectorAll('.paint-layer-row').forEach(row => {
            row.addEventListener('click', (e) => {
                if (e.target.matches('input, select')) return;
                this.engine.setActiveLayer(mesh, this.engine.activeChannelName, parseInt(row.dataset.index, 10));
                this._renderLayerList();
            });
        });
        list.querySelectorAll('.paint-layer-visible').forEach(cb => {
            cb.addEventListener('change', (e) => {
                this.engine.setLayerProp(mesh, this.engine.activeChannelName, parseInt(e.target.dataset.index, 10), 'visible', e.target.checked);
            });
        });
        list.querySelectorAll('.paint-layer-blend').forEach(sel => {
            sel.addEventListener('change', (e) => {
                this.engine.setLayerProp(mesh, this.engine.activeChannelName, parseInt(e.target.dataset.index, 10), 'blendMode', e.target.value);
            });
        });
        list.querySelectorAll('.paint-layer-opacity').forEach(range => {
            range.addEventListener('input', (e) => {
                this.engine.setLayerProp(mesh, this.engine.activeChannelName, parseInt(e.target.dataset.index, 10), 'opacity', parseInt(e.target.value, 10) / 100);
            });
        });
    }

    _exportTextures() {
        const mesh = this.app.selectedObject;
        if (!mesh) return;
        for (const name of CHANNELS) {
            const dataUrl = this.engine.exportChannel(mesh, name);
            const link = document.createElement('a');
            link.href = dataUrl;
            link.download = `${(mesh.userData.name || 'model').replace(/\s+/g, '_')}_${name}.png`;
            link.click();
        }
    }
}
