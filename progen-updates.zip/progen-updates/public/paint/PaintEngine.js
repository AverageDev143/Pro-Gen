import * as THREE from '../vendors/three/build/three.module.js';

/**
 * PaintEngine — ArmorPaint-style layered PBR texture painting for Pro-Gen.
 *
 * Each paintable mesh gets a `paintData` record with one layer stack per
 * PBR channel (albedo / normal / roughness / metalness). Every layer is a
 * plain <canvas>; compositing uses the browser's native 2D blend modes so
 * we don't have to hand-roll Photoshop-style blend math.
 *
 * Painting works directly in UV space: a brush stamp is a radial-gradient
 * disc drawn onto the active layer's canvas at the UV coordinate hit by
 * the raycast, then the channel is recomposited and pushed into a
 * THREE.CanvasTexture already bound to the mesh's material.
 */

export const CHANNELS = ['albedo', 'normal', 'roughness', 'metalness'];

export const CHANNEL_LABELS = {
    albedo: 'Albedo',
    normal: 'Normal',
    roughness: 'Roughness',
    metalness: 'Metalness'
};

// Default "flat" fill per channel — matches Three.js's neutral defaults so a
// freshly-added layer doesn't visually change the model until painted on.
const CHANNEL_DEFAULTS = {
    albedo: null, // filled from the mesh's current material color instead
    normal: 'rgb(128,128,255)',
    roughness: 'rgb(180,180,180)', // ~0.7
    metalness: 'rgb(76,76,76)'     // ~0.3
};

const BLEND_MODES = [
    'source-over', 'multiply', 'screen', 'overlay',
    'darken', 'lighten', 'color-dodge', 'color-burn', 'soft-light'
];

let uidCounter = 1;

function makeCanvas(size) {
    const c = document.createElement('canvas');
    c.width = size;
    c.height = size;
    return c;
}

class PaintLayer {
    constructor(size, name, fillStyle) {
        this.id = uidCounter++;
        this.name = name;
        this.visible = true;
        this.opacity = 1.0;
        this.blendMode = 'source-over';
        this.canvas = makeCanvas(size);
        this.ctx = this.canvas.getContext('2d');
        if (fillStyle) {
            this.ctx.fillStyle = fillStyle;
            this.ctx.fillRect(0, 0, size, size);
        }
    }
}

class PaintChannel {
    constructor(size, fillStyle) {
        this.size = size;
        this.layers = [new PaintLayer(size, 'Base', fillStyle)];
        this.activeLayerIndex = 0;
        this.compositeCanvas = makeCanvas(size);
        this.compositeCtx = this.compositeCanvas.getContext('2d');
        this.texture = new THREE.CanvasTexture(this.compositeCanvas);
        this.texture.wrapS = THREE.RepeatWrapping;
        this.texture.wrapT = THREE.RepeatWrapping;
        this.dirty = true;
    }

    get activeLayer() {
        return this.layers[this.activeLayerIndex];
    }

    composite() {
        const ctx = this.compositeCtx;
        ctx.globalCompositeOperation = 'source-over';
        ctx.globalAlpha = 1;
        ctx.clearRect(0, 0, this.size, this.size);
        for (const layer of this.layers) {
            if (!layer.visible || layer.opacity <= 0) continue;
            ctx.globalAlpha = layer.opacity;
            ctx.globalCompositeOperation = layer.blendMode;
            ctx.drawImage(layer.canvas, 0, 0);
        }
        ctx.globalCompositeOperation = 'source-over';
        ctx.globalAlpha = 1;
        this.texture.needsUpdate = true;
        this.dirty = false;
    }
}

export class PaintEngine {
    constructor(textureSize = 512) {
        this.textureSize = textureSize;
        this.activeChannelName = 'albedo';
    }

    /** Ensure a mesh has paint data + PBR textures wired into its material. */
    ensureMeshPainted(mesh) {
        if (mesh.userData.paintData) return mesh.userData.paintData;

        const baseColorStyle = mesh.material && mesh.material.color
            ? '#' + mesh.material.color.getHexString()
            : '#ffffff';

        const channels = {};
        for (const name of CHANNELS) {
            const fill = name === 'albedo' ? baseColorStyle : CHANNEL_DEFAULTS[name];
            channels[name] = new PaintChannel(this.textureSize, fill);
            channels[name].composite();
        }

        const paintData = { channels };
        mesh.userData.paintData = paintData;
        this._applyMaterial(mesh);
        return paintData;
    }

    /** Swap the mesh's material for a MeshStandardMaterial wired to the paint textures. */
    _applyMaterial(mesh) {
        const pd = mesh.userData.paintData;
        if (!pd) return;
        const old = mesh.material;
        const mat = (old && old.isMeshStandardMaterial) ? old : new THREE.MeshStandardMaterial();
        mat.map = pd.channels.albedo.texture;
        mat.normalMap = pd.channels.normal.texture;
        mat.roughnessMap = pd.channels.roughness.texture;
        mat.metalnessMap = pd.channels.metalness.texture;
        mat.color.set(0xffffff); // let the albedo texture drive color
        mat.roughness = 1.0;
        mat.metalness = 1.0;
        mat.needsUpdate = true;
        if (old !== mat) {
            old?.dispose?.();
            mesh.material = mat;
        }
    }

    setActiveChannel(name) {
        if (CHANNELS.includes(name)) this.activeChannelName = name;
    }

    getChannel(mesh, name = this.activeChannelName) {
        const pd = this.ensureMeshPainted(mesh);
        return pd.channels[name];
    }

    /** Convert a raycast UV hit into canvas pixel coordinates for a channel. */
    uvToPixel(channel, uv) {
        return {
            x: uv.x * channel.size,
            y: (1 - uv.y) * channel.size
        };
    }

    /**
     * Paint a soft circular brush stamp at a UV coordinate on the active
     * layer of the given (or active) channel.
     */
    stamp(mesh, uv, opts = {}) {
        const {
            channelName = this.activeChannelName,
            radius = 24,
            hardness = 0.5,
            opacity = 1,
            color = '#ffffff',
            erase = false
        } = opts;

        const channel = this.getChannel(mesh, channelName);
        const layer = channel.activeLayer;
        const { x, y } = this.uvToPixel(channel, uv);

        const ctx = layer.ctx;
        ctx.save();
        ctx.globalCompositeOperation = erase ? 'destination-out' : 'source-over';
        ctx.globalAlpha = opacity;

        const inner = Math.max(0, Math.min(1, hardness));
        const grad = ctx.createRadialGradient(x, y, radius * inner, x, y, radius);
        grad.addColorStop(0, erase ? 'rgba(0,0,0,1)' : color);
        grad.addColorStop(1, erase ? 'rgba(0,0,0,0)' : hexToTransparent(color));
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        channel.dirty = true;
    }

    /** Paint a straight run of stamps between two UVs (keeps fast strokes gap-free). */
    strokeBetween(mesh, uvFrom, uvTo, opts = {}) {
        const channel = this.getChannel(mesh, opts.channelName || this.activeChannelName);
        const p0 = this.uvToPixel(channel, uvFrom);
        const p1 = this.uvToPixel(channel, uvTo);
        const dist = Math.hypot(p1.x - p0.x, p1.y - p0.y);
        const step = Math.max(1, (opts.radius || 24) * 0.35);
        const steps = Math.max(1, Math.ceil(dist / step));
        for (let i = 1; i <= steps; i++) {
            const t = i / steps;
            const uv = {
                x: uvFrom.x + (uvTo.x - uvFrom.x) * t,
                y: uvFrom.y + (uvTo.y - uvFrom.y) * t
            };
            this.stamp(mesh, uv, opts);
        }
    }

    /** Recomposite any dirty channels for a mesh — call once per animation frame. */
    updateDirty(mesh) {
        const pd = mesh.userData.paintData;
        if (!pd) return;
        for (const name of CHANNELS) {
            if (pd.channels[name].dirty) pd.channels[name].composite();
        }
    }

    addLayer(mesh, channelName = this.activeChannelName, name) {
        const channel = this.getChannel(mesh, channelName);
        const layer = new PaintLayer(channel.size, name || `Layer ${channel.layers.length + 1}`, null);
        channel.layers.push(layer);
        channel.activeLayerIndex = channel.layers.length - 1;
        channel.dirty = true;
        return layer;
    }

    removeLayer(mesh, channelName, layerIndex) {
        const channel = this.getChannel(mesh, channelName);
        if (channel.layers.length <= 1) return false; // keep at least a base layer
        channel.layers.splice(layerIndex, 1);
        channel.activeLayerIndex = Math.max(0, Math.min(channel.activeLayerIndex, channel.layers.length - 1));
        channel.dirty = true;
        return true;
    }

    setActiveLayer(mesh, channelName, layerIndex) {
        const channel = this.getChannel(mesh, channelName);
        channel.activeLayerIndex = Math.max(0, Math.min(layerIndex, channel.layers.length - 1));
    }

    setLayerProp(mesh, channelName, layerIndex, prop, value) {
        const channel = this.getChannel(mesh, channelName);
        const layer = channel.layers[layerIndex];
        if (!layer) return;
        layer[prop] = value;
        channel.dirty = true;
    }

    clearLayer(mesh, channelName, layerIndex) {
        const channel = this.getChannel(mesh, channelName);
        const layer = channel.layers[layerIndex];
        if (!layer) return;
        layer.ctx.clearRect(0, 0, channel.size, channel.size);
        channel.dirty = true;
    }

    /** Export a channel's flattened composite as a PNG data URL. */
    exportChannel(mesh, channelName) {
        const channel = this.getChannel(mesh, channelName);
        if (channel.dirty) channel.composite();
        return channel.compositeCanvas.toDataURL('image/png');
    }
}

function hexToTransparent(hex) {
    // '#rrggbb' -> 'rgba(r,g,b,0)' so the gradient fades to transparent
    // rather than to black at the brush edge.
    const h = hex.replace('#', '');
    const r = parseInt(h.substring(0, 2), 16) || 0;
    const g = parseInt(h.substring(2, 4), 16) || 0;
    const b = parseInt(h.substring(4, 6), 16) || 0;
    return `rgba(${r},${g},${b},0)`;
}

export { BLEND_MODES };
